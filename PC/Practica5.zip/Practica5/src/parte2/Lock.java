package parte2;

public abstract class Lock {
	public abstract void takeLock(int i);
	public abstract void releaseLock(int i);
}
