package parte2;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class LockTicket extends Lock {
	private int N;
	private volatile int next;
	private AtomicInteger number;
	private volatile List<Integer> turn;

	public LockTicket(int N) {
		this.N = N;
		turn = new ArrayList<Integer>(N + 1);
		number = new AtomicInteger(1);
		next = 1;
		for(int i = 0; i <= this.N; ++i)
			turn.add(0);
	}
	
	public void takeLock(int i) {
		turn.set(i, number.getAndIncrement());
		while(turn.get(i) != next);
		turn = turn;
	}

	
	public void releaseLock(int i) {
		++next;		
	}

}
